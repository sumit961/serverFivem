CMVehicles = CMVehicles or {}

CMVehicles.Config = {
    Debug = true,

    Controls = {
        menuKey = 'G',
        lockKey = 'L',
        engineKey = 'LCONTROL', -- Left Ctrl starts/stops engine
        seatbeltKey = 'B',
        cruiseKey = 'CAPITAL'
    },

    Interaction = {
        -- G menu targeting: strict look-at behavior with a forgiving ray for big/custom vehicles.
        distance = 5.8,
        lookDistance = 7.5,
        capsuleRadius = 0.55,
        lookRadius = 0.85,
        lookDot = 0.82,
        screenMargin = 0.22,
        trunkDistance = 4.5,
        keyGiveDistance = 6.0
    },

    TrunkSlotsByLevel = { [0] = 0, [1] = 6, [2] = 12, [3] = 18, [4] = 24, [5] = 30, [6] = 30 },
    DefaultTrunkLevel = 1,

    Commands = { adminSpawnOwned = true },

    Plate = {
        prefix = 'CM',
        length = 6,
        visualBlank = true
    },

    Rules = {
        DefaultSpawnEngineOn = false,
        DeletePlayerVehiclesOnLogout = true,
        DeleteSpawnedVehiclesOnRestart = true,
        ParkingInsuranceFee = 500,
        ParkingRepairOnRetrieve = true
    },

    Persistence = {
        saveIntervalMs = 30000
    },

    Seatbelt = {
        ejectSpeedKmh = 85.0,
        crashDeltaKmh = 45.0,
        warningIntervalMs = 5000
    }
}
