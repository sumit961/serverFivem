local noclip = false
local noclipEntity = 0
local lastGoodGround = nil
local oldAlpha = nil
local oldInvincible = false

local function notify(msg, msgType)
    if GetResourceState('ox_lib') == 'started' and lib and lib.notify then
        lib.notify({ title = 'CM Admin', description = msg, type = msgType or 'inform' })
    else
        print(('[CM-ADMIN] %s'):format(msg))
    end
end

RegisterNetEvent('cm-admin:client:notify', function(msg, msgType)
    notify(msg, msgType)
end)

local function getControlEntity()
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped then
        return veh
    end
    return ped
end

local function rotationToDirection(rot)
    local z = math.rad(rot.z)
    local x = math.rad(rot.x)
    local num = math.abs(math.cos(x))
    return vector3(-math.sin(z) * num, math.cos(z) * num, math.sin(x))
end

local function rightVectorFromForward(forward)
    return vector3(forward.y, -forward.x, 0.0)
end

local function restoreEntity(entity)
    if not entity or entity == 0 or not DoesEntityExist(entity) then return end

    SetEntityCompletelyDisableCollision(entity, false, true)
    SetEntityCollision(entity, true, true)
    SetEntityHasGravity(entity, true)
    SetEntityDynamic(entity, true)
    ActivatePhysics(entity)
    FreezeEntityPosition(entity, false)
    ResetEntityAlpha(entity)
    SetEntityInvincible(entity, false)
    SetEntityVelocity(entity, 0.0, 0.0, 0.0)

    if IsEntityAVehicle(entity) then
        SetVehicleUndriveable(entity, false)
        SetVehicleHandbrake(entity, false)
    end
end

local function restorePed()
    local ped = PlayerPedId()
    restoreEntity(ped)
    SetPlayerControl(PlayerId(), true, 0)
    SetPlayerInvincible(PlayerId(), oldInvincible or false)
    SetPedCanRagdoll(ped, true)
    SetPedCanRagdollFromPlayerImpact(ped, true)
    SetPedConfigFlag(ped, 32, false)
    ResetPedMovementClipset(ped, 0.0)
    ResetPedStrafeClipset(ped)
    ClearPedTasksImmediately(ped)
end

local function applyNoclipState(entity)
    if not entity or entity == 0 or not DoesEntityExist(entity) then return end

    FreezeEntityPosition(entity, true)
    SetEntityVelocity(entity, 0.0, 0.0, 0.0)
    SetEntityHasGravity(entity, false)

    if Config.DisableCollision then
        SetEntityCollision(entity, false, false)
        SetEntityCompletelyDisableCollision(entity, true, true)
    end

    if Config.InvincibleDuringNoclip then
        oldInvincible = GetPlayerInvincible(PlayerId())
        SetEntityInvincible(entity, true)
        SetPlayerInvincible(PlayerId(), true)
    end

    if Config.MakeInvisible then
        oldAlpha = GetEntityAlpha(entity)
        SetEntityAlpha(entity, 120, false)
    end

    if not IsEntityAVehicle(entity) then
        local ped = PlayerPedId()
        SetPedCanRagdoll(ped, false)
        SetPedCanRagdollFromPlayerImpact(ped, false)
    else
        SetVehicleUndriveable(entity, false)
        SetVehicleHandbrake(entity, false)
    end
end

local function raycastSurfaceBelow(coords)
    local ray = StartShapeTestRay(coords.x, coords.y, coords.z + 8.0, coords.x, coords.y, coords.z - 80.0, 1, PlayerPedId(), 7)
    local _, hit, hitCoords = GetShapeTestResult(ray)
    if hit == 1 and hitCoords then
        return vector3(hitCoords.x, hitCoords.y, hitCoords.z + 1.05)
    end
    return nil
end

local function groundAt(coords)
    RequestCollisionAtCoord(coords.x, coords.y, coords.z)

    local surface = raycastSurfaceBelow(coords)
    if surface then return surface end

    for i = 1, 20 do
        local found, groundZ = GetGroundZFor_3dCoord(coords.x, coords.y, coords.z + 100.0, false)
        if found then
            return vector3(coords.x, coords.y, groundZ + 1.05)
        end
        Wait(0)
    end

    return nil
end

local function safeStandingCoords(coords)
    local found = groundAt(coords)
    if found then return found end

    if lastGoodGround then return lastGoodGround end

    local safe = Config.SafeCoords or vector4(215.76, -810.12, 30.73, 157.0)
    return vector3(safe.x, safe.y, safe.z + 0.5)
end

local function standEntitySafely(entity)
    if not entity or entity == 0 or not DoesEntityExist(entity) then return end

    local coords = GetEntityCoords(entity)
    local exitCoords = safeStandingCoords(coords)

    RequestCollisionAtCoord(exitCoords.x, exitCoords.y, exitCoords.z)

    restoreEntity(entity)
    restorePed()

    FreezeEntityPosition(entity, true)
    SetEntityCoordsNoOffset(entity, exitCoords.x, exitCoords.y, exitCoords.z, false, false, true)

    local start = GetGameTimer()
    while GetGameTimer() - start < 500 do
        RequestCollisionAtCoord(exitCoords.x, exitCoords.y, exitCoords.z)
        Wait(0)
    end

    restoreEntity(entity)
    restorePed()
    FreezeEntityPosition(entity, false)

    if IsEntityAVehicle(entity) then
        SetVehicleOnGroundProperly(entity)
    end
end

local function disableNoclip()
    if not noclip then return end
    noclip = false

    local entity = (noclipEntity ~= 0 and DoesEntityExist(noclipEntity)) and noclipEntity or getControlEntity()
    standEntitySafely(entity)

    noclipEntity = 0
    oldAlpha = nil
    notify('Noclip disabled. Player placed on safe ground.', 'inform')
end

local function enableNoclip()
    if noclip then return end
    local entity = getControlEntity()
    noclip = true
    noclipEntity = entity
    lastGoodGround = groundAt(GetEntityCoords(entity)) or GetEntityCoords(entity)
    applyNoclipState(entity)
    notify('Noclip enabled. F2 again to disable.', 'success')
end

local function toggleNoclip()
    if noclip then disableNoclip() else enableNoclip() end
end

RegisterNetEvent('cm-admin:client:toggleNoclip', toggleNoclip)

RegisterCommand(Config.KeybindCommand or 'cm_admin_noclip_toggle', function()
    TriggerServerEvent('cm-admin:server:requestNoclipToggle')
end, false)
RegisterKeyMapping(Config.KeybindCommand or 'cm_admin_noclip_toggle', 'CM Admin: Toggle noclip', 'keyboard', Config.DefaultKey or 'F2')

CreateThread(function()
    while true do
        if not noclip then
            Wait(250)
        else
            Wait(0)

            local entity = noclipEntity
            if not entity or entity == 0 or not DoesEntityExist(entity) then
                entity = getControlEntity()
                noclipEntity = entity
            end

            applyNoclipState(entity)

            DisableControlAction(0, 30, true)
            DisableControlAction(0, 31, true)
            DisableControlAction(0, 32, true)
            DisableControlAction(0, 33, true)
            DisableControlAction(0, 34, true)
            DisableControlAction(0, 35, true)
            DisableControlAction(0, 22, true)
            DisableControlAction(0, 36, true)
            DisableControlAction(0, 75, true)

            local speed = Config.Speeds.normal or 1.6
            if IsDisabledControlPressed(0, 21) then
                speed = Config.Speeds.fast or 5.8
            elseif IsDisabledControlPressed(0, 19) then
                speed = Config.Speeds.slow or 0.35
            end

            local camRot = GetGameplayCamRot(2)
            local forward = rotationToDirection(camRot)
            local right = rightVectorFromForward(forward)
            local pos = GetEntityCoords(entity)
            local move = vector3(0.0, 0.0, 0.0)

            if IsDisabledControlPressed(0, 32) then move = move + forward end
            if IsDisabledControlPressed(0, 33) then move = move - forward end
            if IsDisabledControlPressed(0, 35) then move = move + right end
            if IsDisabledControlPressed(0, 34) then move = move - right end
            if IsDisabledControlPressed(0, 22) or IsControlPressed(0, 38) then move = move + vector3(0.0, 0.0, 1.0) end
            if IsDisabledControlPressed(0, 36) or IsControlPressed(0, 44) then move = move - vector3(0.0, 0.0, 1.0) end

            if #(move) > 0.0 then
                move = move / #(move)
                pos = pos + (move * speed)
                SetEntityCoordsNoOffset(entity, pos.x, pos.y, pos.z, false, false, true)
            end

            SetEntityVelocity(entity, 0.0, 0.0, 0.0)
            SetEntityHeading(entity, camRot.z)

            -- Save a recent valid standing surface, but only when it is close below us.
            if GetGameTimer() % 750 < 20 then
                local g = groundAt(GetEntityCoords(entity))
                if g and #(g - GetEntityCoords(entity)) < 8.0 then
                    lastGoodGround = g
                end
            end

            if Config.ShowHelp then
                BeginTextCommandDisplayHelp('STRING')
                AddTextComponentSubstringPlayerName(('NOCLIP ON | %.1f | W/S/A/D | Space/E up | Ctrl/Q down | Shift fast | Alt slow | F2 off'):format(speed))
                EndTextCommandDisplayHelp(0, false, false, -1)
            end
        end
    end
end)

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end
    if noclip then disableNoclip() end
    restorePed()
end)

RegisterCommand('cmunstuck', function()
    if noclip then noclip = false end
    local entity = getControlEntity()
    standEntitySafely(entity)
    notify('Placed on safe standing ground.', 'success')
end, false)

RegisterCommand('cmstand', function()
    local entity = getControlEntity()
    standEntitySafely(entity)
    notify('Forced player to stand on nearest surface.', 'success')
end, false)

RegisterCommand('cmup', function(_, args)
    local entity = getControlEntity()
    local amount = tonumber(args[1]) or 2.0
    restoreEntity(entity)
    restorePed()
    local pos = GetEntityCoords(entity)
    SetEntityCoordsNoOffset(entity, pos.x, pos.y, pos.z + amount, false, false, true)
    notify(('Moved up %.1fm.'):format(amount), 'success')
end, false)

RegisterCommand('cmsafe', function()
    local entity = getControlEntity()
    local safe = Config.SafeCoords or vector4(215.76, -810.12, 30.73, 157.0)
    restoreEntity(entity)
    restorePed()
    FreezeEntityPosition(entity, true)
    RequestCollisionAtCoord(safe.x, safe.y, safe.z)
    SetEntityCoordsNoOffset(entity, safe.x, safe.y, safe.z + 0.5, false, false, true)
    Wait(500)
    restoreEntity(entity)
    restorePed()
    FreezeEntityPosition(entity, false)
    notify('Teleported to safe test point.', 'success')
end, false)

RegisterCommand('getcampos', function()
    local ped = PlayerPedId()

    local pedCoords = GetEntityCoords(ped)
    local pedHeading = GetEntityHeading(ped)

    local camCoord = GetGameplayCamCoord()
    local camRot = GetGameplayCamRot(2)
    local camFov = GetGameplayCamFov()

    print('==============================')
    print('PLAYER POSITION')
    print(string.format(
        'vector4(%.4f, %.4f, %.4f, %.4f)',
        pedCoords.x,
        pedCoords.y,
        pedCoords.z,
        pedHeading
    ))

    print('CAMERA POSITION')
    print(string.format(
        'vector3(%.4f, %.4f, %.4f)',
        camCoord.x,
        camCoord.y,
        camCoord.z
    ))

    print('CAMERA ROTATION')
    print(string.format(
        'vector3(%.4f, %.4f, %.4f)',
        camRot.x,
        camRot.y,
        camRot.z
    ))

    print('CAMERA FOV')
    print(camFov)

    print('==============================')
end)

-- Get current camera position + where it is looking.
-- Use in F8:
--   vehcamcurrent
-- It prints config lines for:
--   Config.VehicleAdminStudio.camera
--   Config.VehicleAdminStudio.cameraLookAt
--   Config.VehicleAdminStudio.cameraFov

local function rnFmt(n)
    return string.format('%.4f', tonumber(n) or 0.0)
end

local function rnRotationToDirection(rot)
    local z = math.rad(rot.z)
    local x = math.rad(rot.x)
    local num = math.abs(math.cos(x))

    return vector3(
        -math.sin(z) * num,
        math.cos(z) * num,
        math.sin(x)
    )
end

local function rnGetCurrentCameraData()
    local cam = GetRenderingCam()
    local camCoords, camRot, camFov

    -- If script camera is active, read it.
    -- Otherwise read normal gameplay camera.
    if cam and cam ~= -1 and DoesCamExist(cam) then
        camCoords = GetCamCoord(cam)
        camRot = GetCamRot(cam, 2)
        camFov = GetCamFov(cam)
    else
        camCoords = GetGameplayCamCoord()
        camRot = GetGameplayCamRot(2)
        camFov = GetGameplayCamFov()
    end

    local dir = rnRotationToDirection(camRot)
    local far = camCoords + (dir * 80.0)

    local ray = StartShapeTestRay(
        camCoords.x,
        camCoords.y,
        camCoords.z,
        far.x,
        far.y,
        far.z,
        -1,
        PlayerPedId(),
        0
    )

    local _, hit, hitCoords = GetShapeTestResult(ray)

    -- If raycast does not hit anything, use point in front of camera.
    if hit ~= 1 then
        hitCoords = camCoords + (dir * 8.0)
    end

    return camCoords, hitCoords, camFov
end

RegisterCommand('vehcamcurrent', function()
    local camCoords, lookAt, fov = rnGetCurrentCameraData()

    print('')
    print('[rn-vehicleshop] Camera config from current view:')
    print(('Config.VehicleAdminStudio.camera = vector3(%s, %s, %s)'):format(
        rnFmt(camCoords.x),
        rnFmt(camCoords.y),
        rnFmt(camCoords.z)
    ))
    print(('Config.VehicleAdminStudio.cameraLookAt = vector3(%s, %s, %s)'):format(
        rnFmt(lookAt.x),
        rnFmt(lookAt.y),
        rnFmt(lookAt.z)
    ))
    print(('Config.VehicleAdminStudio.cameraFov = %.1f'):format(fov))
    print('')

    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName('Camera position printed in F8 console.')
    EndTextCommandThefeedPostTicker(false, false)
end, false)
