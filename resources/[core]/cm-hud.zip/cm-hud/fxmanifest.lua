fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'CM / Wais HUD adapted for cm-core'
version '1.0.0-cmcore-option-a'
description 'Wais-style HUD converted for cm-core. Option A folder structure. No hunger/thirst/stamina/stress.'

shared_scripts {
    'config/config.lua',
    'shared/*.lua'
}

client_scripts {
    'client/seatbelt.lua',
    'client/main.lua'
}

server_scripts {
    'server/main.lua'
}

ui_page 'ui/index.html'

files {
    'ui/index.html',
    'ui/app.js',
    'ui/style.css',
    'ui/public/*.png',
    'ui/public/*.json',
    'ui/public/css/*.*',
    'ui/public/assets/*.*',
    'ui/public/weapons/*.*',
    'ui/public/menu-items/*.*',
    'ui/public/notification/*.*',
    'ui/public/carhud-images/*.*',
    'sounds/*.ogg',
    'stream/*.gfx',
    'stream/*.ytd'
}
