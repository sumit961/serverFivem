local function getPlayerData(src)
    local data = { cash = 0, bank = 0, job = 'Unemployed', jobGrade = 0, jobLabel = 'Unemployed', gradeLabel = '0' }

    local okPlayer, player = pcall(function() return exports['cm-core']:GetPlayer(src) end)
    if okPlayer and player and player.Character then
        local ch = player.Character
        data.cash = tonumber(ch.cash) or 0
        data.bank = tonumber(ch.bank) or 0
        data.job = ch.job or 'Unemployed'
        data.jobGrade = tonumber(ch.job_grade or ch.grade or 0) or 0
        data.jobLabel = ch.job_label or ch.jobLabel or data.job
        data.gradeLabel = ch.grade_label or ch.gradeLabel or tostring(data.jobGrade)
        return data
    end

    local okChar, ch = pcall(function() return exports['cm-core']:GetCharacter(src) end)
    if okChar and ch then
        data.cash = tonumber(ch.cash) or 0
        data.bank = tonumber(ch.bank) or 0
        data.job = ch.job or 'Unemployed'
        data.jobGrade = tonumber(ch.job_grade or ch.grade or 0) or 0
        data.jobLabel = ch.job_label or ch.jobLabel or data.job
        data.gradeLabel = ch.grade_label or ch.gradeLabel or tostring(data.jobGrade)
    else
        local okCash, cash = pcall(function() return exports['cm-core']:GetMoney(src, 'cash') end)
        local okBank, bank = pcall(function() return exports['cm-core']:GetMoney(src, 'bank') end)
        if okCash then data.cash = tonumber(cash) or 0 end
        if okBank then data.bank = tonumber(bank) or 0 end
    end
    return data
end

RegisterNetEvent('cm-hud:server:requestData', function()
    local src = source
    TriggerClientEvent('cm-hud:client:setData', src, getPlayerData(src))
end)

RegisterNetEvent('wais:requestCurrentPlayers', function()
    local src = source
    local total = #GetPlayers()
    local maxPlayers = GetConvarInt('sv_maxclients', 32)
    TriggerClientEvent('wais:updateCurrentPlayers', src, total, maxPlayers)
end)

AddEventHandler('cm-core:server:playerRegistered', function(src)
    TriggerClientEvent('cm-hud:client:setData', src, getPlayerData(src))
end)

AddEventHandler('cm-core:moneyChanged', function(src)
    TriggerClientEvent('cm-hud:client:setData', src, getPlayerData(src))
end)

CreateThread(function()
    while true do
        local total = #GetPlayers()
        local maxPlayers = GetConvarInt('sv_maxclients', 32)
        TriggerClientEvent('wais:updateCurrentPlayers', -1, total, maxPlayers)
        Wait(Config.RefreshTimes.playercounts or 30000)
    end
end)
