CM HUD - Option A structure

Install:
1. Delete your old cm-hud folder completely.
2. Extract this zip.
3. Make sure the folder name is exactly: cm-hud
4. In server.cfg:
   ensure cm-core
   ensure cm-hud

Commands:
/hud
/hudedit
/hudtest
/hudreset
/cinematic
/minimap circle
/minimap square

Seatbelt key: B

Structure:
client/  = client scripts
server/  = server scripts
config/  = config
shared/  = shared helpers
ui/      = NUI files
