local PlayerData = { cash = 0, bank = 0, job = 'Unemployed', jobGrade = 0 }
local carhudtype, speedtype, maptype, statusbartype = 'new', 'kmh', 'squared', 'newest'
local nuiloaded, playerLoaded = false, false
local pauseMenuActive, radarHideForTrigger, hudHideForTrigger = false, false, false
local carhudHideForTrigger, inCar, inRadioTalking, cinematicMode = false, false, false, false
local blackList, blackListControl, beltIgnore = false, false, false
local lightState = false
seatbeltOn = false

local screen = { x = 0, y = 0 }
local model = nil
local p = PlayerId()

local function clamp(n, min, max)
    n = tonumber(n) or 0
    if n < min then return min end
    if n > max then return max end
    return n
end

local function cmNotify(ntype, title, text, time)
    SendNUIMessage({ type = 'ADD_NOTIFICATION', ntype = ntype or 'info', types = ntype or 'info', title = title or 'Information', text = text or '', message = text or '', time = time or 3000, timeout = time or 3000 })
end

RegisterNetEvent('wais:addNotification', function(typee, title, text, time)
    cmNotify(typee, title, text, time)
end)

exports('Notify', function(text, ntype, time, title)
    cmNotify(ntype or 'info', title or 'Information', text or '', time or 3000)
end)

RegisterCommand('hud', function() SettingsMenu() end, false)
RegisterCommand('hudedit', function() Customization() end, false)
RegisterCommand('cinematic', function()
    cinematicMode = not cinematicMode
    SendNUIMessage({ type = 'SETTINGS_MENU', state = false })
    cmNotify('info', 'HUD', cinematicMode and 'Cinematic mode enabled.' or 'Cinematic mode disabled.', 2500)
end, false)

RegisterCommand('hudreset', function()
    SendNUIMessage({ type = 'CM_CLEAR_STORAGE' })
    Wait(250)
    SendNUIMessage({ type = 'RELOAD_PAGE' })
    cmNotify('success', 'HUD', 'HUD cache reset. Restart cm-hud if needed.', 4000)
end, false)

RegisterCommand('hudtest', function()
    print(('[cm-hud] test: nuiloaded=%s playerLoaded=%s resource=%s'):format(tostring(nuiloaded), tostring(playerLoaded), GetCurrentResourceName()))
    SendNUIMessage({ type = 'PLAYER_LOADED', playerId = GetPlayerServerId(PlayerId()) })
    SendNUIMessage({ type = 'UPDATE_CURRENT_PLAYERS', players = #GetActivePlayers(), maxplayers = GetConvarInt('sv_maxclients', 32) })
    SendNUIMessage({ type = 'UPDATE_CASH', cash = PlayerData.cash or 0, firstTime = true })
    SendNUIMessage({ type = 'UPDATE_BANK', bank = PlayerData.bank or 0, firstTime = true })
    SendNUIMessage({ type = 'UPDATE_JOB', label = tostring(PlayerData.jobLabel or PlayerData.job or 'Unemployed') .. ' - ' .. tostring(PlayerData.gradeLabel or PlayerData.jobGrade or 0) })
    SendNUIMessage({ type = 'UPDATE_STATUS', health = 100, armour = 0, hunger = 0, thirst = 0, stamina = 0, inwater = false, stress = 0 })
    SendNUIMessage({ type = 'UPDATE_MIC_DISTANCE', distance = 35 })
    SendNUIMessage({ type = 'ADD_NOTIFICATION', ntype = 'success', types = 'success', title = 'cm-hud', text = 'HUD test message', message = 'HUD test message', time = 5000, timeout = 5000 })
end, false)


RegisterCommand('hudforce', function()
    nuiloaded = true
    playerLoaded = true
    requestPlayerData()
    SendNUIMessage({ type = 'DEFAULT_VERIABLES', symbol = Config.MoneySettings.formatSymbol, prefix = Config.MoneySettings.formatPrefix, clock = Config.ClockType, useStress = false, showOnlyInCar = Config.ShowMapOnlyInTheCar, exitcustomization = Config.Keybind.editormode.key })
    SendNUIMessage({ type = 'SEND_KEYBINDS', keybinds = Config.Keybinds })
    SendNUIMessage({ type = 'PLAYER_LOADED', playerId = GetPlayerServerId(PlayerId()) })
    SendNUIMessage({ type = 'UPDATE_CURRENT_PLAYERS', players = #GetActivePlayers(), maxplayers = GetConvarInt('sv_maxclients', 32) })
    SendNUIMessage({ type = 'UPDATE_CASH', cash = PlayerData.cash or 0, firstTime = true })
    SendNUIMessage({ type = 'UPDATE_BANK', bank = PlayerData.bank or 0, firstTime = true })
    SendNUIMessage({ type = 'UPDATE_JOB', label = tostring(PlayerData.jobLabel or PlayerData.job or 'Unemployed') .. ' - ' .. tostring(PlayerData.gradeLabel or PlayerData.jobGrade or 0) })
    SendNUIMessage({ type = 'UPDATE_STATUS', health = 100, armour = 0, hunger = 0, thirst = 0, stamina = 0, inwater = false, stress = 0 })
    cmNotify('success', 'cm-hud', 'Forced HUD init sent.', 4000)
end, false)

RegisterCommand('minimap', function(_, args)
    local wanted = args[1]
    if wanted == 'circle' or wanted == 'round' or wanted == 'rounded' then
        maptype = 'rounded'
    elseif wanted == 'square' or wanted == 'squared' then
        maptype = 'squared'
    else
        cmNotify('info', 'HUD', 'Use /minimap circle or /minimap square', 3500)
        return
    end
    buildmap()
    cmNotify('success', 'HUD', ('Minimap changed to %s.'):format(maptype), 2500)
end, false)

local function setPlayerData(data)
    data = data or {}
    PlayerData.cash = tonumber(data.cash) or tonumber(LocalPlayer.state.cash) or 0
    PlayerData.bank = tonumber(data.bank) or tonumber(LocalPlayer.state.bank) or 0
    PlayerData.job = data.job or LocalPlayer.state.job or 'Unemployed'
    PlayerData.jobGrade = tonumber(data.jobGrade or LocalPlayer.state.jobGrade) or 0
    PlayerData.jobLabel = data.jobLabel or PlayerData.job
    PlayerData.gradeLabel = data.gradeLabel or tostring(PlayerData.jobGrade)
end

local function jobLabel()
    local job = tostring(PlayerData.jobLabel or PlayerData.job or 'Unemployed')
    local grade = tostring(PlayerData.gradeLabel or PlayerData.jobGrade or 0)
    return ('%s - %s'):format(job, grade)
end

local function requestPlayerData()
    TriggerServerEvent('cm-hud:server:requestData')
    TriggerServerEvent('wais:requestCurrentPlayers')
end

RegisterNetEvent('cm-hud:client:setData', function(data)
    setPlayerData(data)
    if nuiloaded then
        SendNUIMessage({ type = 'UPDATE_CASH', cash = PlayerData.cash, firstTime = not playerLoaded })
        SendNUIMessage({ type = 'UPDATE_BANK', bank = PlayerData.bank, firstTime = not playerLoaded })
        SendNUIMessage({ type = 'UPDATE_JOB', label = jobLabel() })
    end
end)

RegisterNetEvent('cm-core:client:stateUpdate', function(namespace, key, value)
    if key == 'cash' then
        PlayerData.cash = tonumber(value) or PlayerData.cash
        SendNUIMessage({ type = 'UPDATE_CASH', cash = PlayerData.cash, firstTime = false })
    elseif key == 'bank' then
        PlayerData.bank = tonumber(value) or PlayerData.bank
        SendNUIMessage({ type = 'UPDATE_BANK', bank = PlayerData.bank, firstTime = false })
    elseif key == 'job' or key == 'jobGrade' then
        if key == 'job' then PlayerData.job = value or PlayerData.job end
        if key == 'jobGrade' then PlayerData.jobGrade = value or PlayerData.jobGrade end
        SendNUIMessage({ type = 'UPDATE_JOB', label = jobLabel() })
    end
end)

AddStateBagChangeHandler('cash', nil, function(_, _, value)
    PlayerData.cash = tonumber(value) or PlayerData.cash
    if nuiloaded then SendNUIMessage({ type = 'UPDATE_CASH', cash = PlayerData.cash, firstTime = false }) end
end)
AddStateBagChangeHandler('bank', nil, function(_, _, value)
    PlayerData.bank = tonumber(value) or PlayerData.bank
    if nuiloaded then SendNUIMessage({ type = 'UPDATE_BANK', bank = PlayerData.bank, firstTime = false }) end
end)
AddStateBagChangeHandler('job', nil, function(_, _, value)
    PlayerData.job = value or PlayerData.job
    if nuiloaded then SendNUIMessage({ type = 'UPDATE_JOB', label = jobLabel() }) end
end)
AddStateBagChangeHandler('jobGrade', nil, function(_, _, value)
    PlayerData.jobGrade = tonumber(value) or PlayerData.jobGrade
    if nuiloaded then SendNUIMessage({ type = 'UPDATE_JOB', label = jobLabel() }) end
end)

RegisterNetEvent('cm-core:moneyChanged', function(_, account, _, _, balanceAfter)
    if account == 'cash' then
        PlayerData.cash = tonumber(balanceAfter) or PlayerData.cash
        SendNUIMessage({ type = 'UPDATE_CASH', cash = PlayerData.cash, firstTime = false })
    elseif account == 'bank' then
        PlayerData.bank = tonumber(balanceAfter) or PlayerData.bank
        SendNUIMessage({ type = 'UPDATE_BANK', bank = PlayerData.bank, firstTime = false })
    end
end)

RegisterNetEvent('wais:updateCurrentPlayers', function(players, maxplayers)
    SendNUIMessage({ type = 'UPDATE_CURRENT_PLAYERS', players = players or 1, maxplayers = maxplayers or 32 })
end)

RegisterNetEvent('pma-voice:setTalkingMode', function(ranges)
    local r = Config.VoiceSettings.pma[ranges] or Config.VoiceSettings.pma[1]
    SendNUIMessage({ type = 'UPDATE_MIC_DISTANCE', distance = r.meter })
end)
RegisterNetEvent('pma-voice:radioActive', function(talking) inRadioTalking = talking end)
RegisterNetEvent('SaltyChat_TalkStateChanged', function(status)
    SendNUIMessage({ type = 'UPDATE_MIC', state = status, radio = inRadioTalking })
end)
RegisterNetEvent('SaltyChat_RadioTrafficStateChanged', function(_, isSending) inRadioTalking = isSending end)
RegisterNetEvent('SaltyChat_VoiceRangeChanged', function(range)
    local r = Config.VoiceSettings.saltychat.ranges[tostring(range)] or Config.VoiceSettings.saltychat.ranges[Config.VoiceSettings.saltychat.default]
    SendNUIMessage({ type = 'UPDATE_MIC_DISTANCE', distance = r.meter })
end)


-- Compatibility callbacks for the original Wais compiled UI.
-- The compiled UI is now patched to call nuiloaded directly, but these keep old/cache builds from hanging.
RegisterNUICallback('nuiLoaded', function(_, cb)
    cb('nuiLoadedOk')
end)
RegisterNUICallback('nuiLoadedOk', function(_, cb)
    cb('M6KLjfaB')
end)

RegisterNUICallback('uierror', function(data, cb)
    print(('[cm-hud] NUI ERROR: %s (%s:%s)'):format(tostring(data and data.message), tostring(data and data.source), tostring(data and data.line)))
    cb({ ok = true })
end)

RegisterNUICallback('nuiloaded', function(data, cb)
    data = data or {}
    nuiloaded = true
    carhudtype = data.carhudtype or carhudtype or 'new'
    speedtype = data.speedtype or speedtype or 'kmh'
    maptype = data.maptype or maptype or 'squared'
    statusbartype = data.statusbartype or statusbartype or 'newest'
    screen.x, screen.y = GetActiveScreenResolution()

    SendNUIMessage({
        type = 'DEFAULT_VERIABLES',
        symbol = Config.MoneySettings.formatSymbol,
        prefix = Config.MoneySettings.formatPrefix,
        clock = Config.ClockType,
        useStress = false,
        showOnlyInCar = Config.ShowMapOnlyInTheCar,
        exitcustomization = Config.Keybind.editormode.key,
    })
    SendNUIMessage({ type = 'SEND_KEYBINDS', keybinds = Config.Keybinds })
    SendNUIMessage({ type = 'UPDATE_MIC_DISTANCE', distance = Config.VoiceSettings.pma[1].meter })

    requestPlayerData()
    SendNUIMessage({ type = 'PLAYER_LOADED', playerId = GetPlayerServerId(PlayerId()) })
    SendNUIMessage({ type = 'UPDATE_CASH', cash = PlayerData.cash, firstTime = true })
    SendNUIMessage({ type = 'UPDATE_BANK', bank = PlayerData.bank, firstTime = true })
    SendNUIMessage({ type = 'UPDATE_JOB', label = jobLabel() })
    playerLoaded = true
    buildmap()
    cb({ ok = true })
end)

RegisterNUICallback('setcarhud', function(data, cb)
    carhudtype = data.hud or carhudtype
    cb({ ok = true })
end)
RegisterNUICallback('setmaptype', function(data, cb)
    maptype = data.map or maptype
    buildmap()
    cb({ ok = true })
end)
RegisterNUICallback('setspeedtype', function(data, cb)
    speedtype = data.speed or speedtype
    cb({ ok = true })
end)
RegisterNUICallback('setstatusbartype', function(data, cb)
    statusbartype = data.statusbar or statusbartype
    buildmap()
    cb({ ok = true })
end)
RegisterNUICallback('cinematicmode', function(data, cb)
    cinematicMode = data.state == true
    cb({ ok = true })
end)
RegisterNUICallback('closeSettings', function(_, cb)
    SendNUIMessage({ type = 'SETTINGS_MENU', state = false })
    SetNuiFocus(false, false)
    cb({ ok = true })
end)
RegisterNUICallback('closeEditorMode', function(_, cb)
    SendNUIMessage({ type = 'CUSTOMIZATION_MENU', state = false })
    SetNuiFocus(false, false)
    cb({ ok = true })
end)

function SettingsMenu()
    SetNuiFocus(true, true)
    SendNUIMessage({ type = 'SETTINGS_MENU', state = true })
    if not nuiloaded then
        print('[cm-hud] /hud used but NUI has not called nuiloaded yet. Check NUI dev console for errors.')
    end
end

function Customization()
    SetNuiFocus(true, true)
    SendNUIMessage({ type = 'CUSTOMIZATION_MENU', state = true })
    if not nuiloaded then
        print('[cm-hud] /hudedit used but NUI has not called nuiloaded yet. Check NUI dev console for errors.')
    end
end

local function hasBlackListVehicle(modelHash, blacklistType)
    local class = GetVehicleClass(GetVehiclePedIsUsing(PlayerPedId()))
    if class == 8 or class == 13 or class == 14 then beltIgnore = true end
    blackList = false
    for k, v in pairs(Config.BlackListVehicle or {}) do
        if GetHashKey(k) == modelHash then
            blackList = v[blacklistType] == true
            beltIgnore = v.belt == true
            break
        end
    end
    blackListControl = true
end

function buildmap()
    screen.x, screen.y = GetActiveScreenResolution()
    if maptype == 'squared' then
        RequestStreamedTextureDict('squaremap', false)
        local timeout = GetGameTimer() + 1500
        while not HasStreamedTextureDictLoaded('squaremap') and GetGameTimer() < timeout do Wait(50) end
        SetMinimapClipType(0)
        AddReplaceTexture('platform:/textures/graphics', 'radarmasksm', 'squaremap', 'radarmasksm')
        AddReplaceTexture('platform:/textures/graphics', 'radarmask1g', 'squaremap', 'radarmasksm')
        SetMinimapComponentPosition('minimap', 'L', 'B', 0.0, -0.007, 0.1638, 0.183)
        SetMinimapComponentPosition('minimap_mask', 'L', 'B', 0.0, 0.0, 0.128, 0.20)
        SetMinimapComponentPosition('minimap_blur', 'L', 'B', 0.0, statusbartype == 'old' and 0.0 or 0.025, 0.262, 0.300)
    else
        RequestStreamedTextureDict('circlemap', false)
        local timeout = GetGameTimer() + 1500
        while not HasStreamedTextureDictLoaded('circlemap') and GetGameTimer() < timeout do Wait(50) end
        SetMinimapClipType(1)
        AddReplaceTexture('platform:/textures/graphics', 'radarmasksm', 'circlemap', 'radarmasksm')
        SetMinimapComponentPosition('minimap', 'L', 'B', 0.0, -0.015, 0.16, 0.25)
        SetMinimapComponentPosition('minimap_mask', 'L', 'B', 0.145, 0.075, 0.072, 0.162)
        SetMinimapComponentPosition('minimap_blur', 'L', 'B', -0.010, 0.00, 0.18, 0.22)
    end
    SetBlipAlpha(GetNorthRadarBlip(), 0)
    SetRadarBigmapEnabled(true, false)
    Wait(50)
    SetRadarBigmapEnabled(false, false)
end

CreateThread(function()
    while not nuiloaded do Wait(250) end
    requestPlayerData()
end)

CreateThread(function()
    while true do
        local ped = PlayerPedId()
        local sleep = Config.RefreshTimes.hud
        local maxHealth = GetEntityMaxHealth(ped)
        local health = maxHealth == 175 and (GetEntityHealth(ped) + 25) - 100 or GetEntityHealth(ped) - 100
        local armour = GetPedArmour(ped)
        local pos = GetEntityCoords(ped)
        p = PlayerId()

        if playerLoaded then
            if not IsPauseMenuActive() then
                local weapon = GetSelectedPedWeapon(ped)
                local ammo = GetAmmoInPedWeapon(ped, weapon)
                local _, ammoClip = GetAmmoInClip(ped, weapon)
                local street1, street2 = GetStreetNameAtCoord(pos.x, pos.y, pos.z)
                local waypoint = GetFirstBlipInfoId(8)
                local remaining = waypoint ~= 0 and math.floor(#(GetBlipCoords(waypoint) - pos)) or 0

                SetPedConfigFlag(ped, 35, false)

                if IsPedInAnyVehicle(ped, false) then
                    sleep = Config.RefreshTimes.carhud
                    local veh = GetVehiclePedIsIn(ped, false)
                    model = GetEntityModel(veh)
                    if not blackListControl then hasBlackListVehicle(model, 'carhud') end
                    if not blackList then
                        local _, lightsOn, highbeams = GetVehicleLightsState(veh)
                        local doorOpen = false
                        for i = 0, 5 do
                            if GetVehicleDoorAngleRatio(veh, i) ~= 0 then doorOpen = true break end
                        end
                        lightState = lightsOn == 1 or highbeams == 1
                        SendNUIMessage({
                            type = 'VEHICLE_STATUS',
                            speed = GetEntitySpeed(veh),
                            fuel = math.floor(GetVehicleFuelLevel(veh)),
                            rpm = math.floor(GetVehicleCurrentRpm(veh) * 9),
                            gear = GetVehicleCurrentGear(veh),
                            maxgear = GetVehicleHighGear(veh),
                            door = doorOpen,
                            seatbelt = seatbeltOn,
                            light = lightState,
                            engine = GetIsVehicleEngineRunning(veh),
                            handbrake = GetVehicleHandbrake(veh),
                            engineDamage = math.floor(GetVehicleEngineHealth(veh)),
                            bodyDamage = math.floor(GetVehicleBodyHealth(veh)),
                            oilValue = math.floor(GetVehiclePetrolTankHealth(veh)),
                        })
                        if not inCar then
                            inCar = true
                            TriggerEvent('EnteredVehicle')
                            SendNUIMessage({ type = 'PLAYER_INCAR' })
                        end
                    end
                else
                    model = nil
                    blackList = false
                    beltIgnore = false
                    if inCar then
                        lastFrameVehiclespeed2 = 0
                        lastFrameVehiclespeed = 0
                        newvehicleBodyHealth = 0
                        currentvehicleBodyHealth = 0
                        frameBodyChange = 0
                        seatbeltOn = false
                        inCar = false
                        blackListControl = false
                        SendNUIMessage({ type = 'PLAYER_OUTCAR' })
                    end
                end

                if (not Config.ShowMapOnlyInTheCar) or inCar then
                    SendNUIMessage({
                        type = 'UPDATE_LOCATION',
                        streetTitle = GetStreetNameFromHashKey(street1),
                        streetName = GetStreetNameFromHashKey(street2),
                        remaining = IsWaypointActive(),
                        remainingDistance = remaining
                    })
                end

                SendNUIMessage({
                    type = 'UPDATE_STATUS',
                    health = clamp(health, 0, 100),
                    armour = clamp(armour, 0, 100),
                    hunger = 0,
                    thirst = 0,
                    stamina = 0,
                    inwater = IsEntityInWater(ped),
                    stress = 0
                })

                SendNUIMessage({
                    type = 'UPDATE_WEAPON',
                    label = Config.Weapons[weapon] and Config.Weapons[weapon].label or tostring(weapon),
                    image = Config.Weapons[weapon] and Config.Weapons[weapon].image or weapon,
                    ammo = ammoClip or 0,
                    clip = math.max((ammo or 0) - (ammoClip or 0), 0)
                })

                if not pauseMenuActive then
                    pauseMenuActive = true
                    if not hudHideForTrigger then SendNUIMessage({ type = 'PAUSEMENU_STATE', state = false }) end
                end
            else
                pauseMenuActive = false
                SendNUIMessage({ type = 'PAUSEMENU_STATE', state = true })
            end

            SendNUIMessage({ type = 'UPDATE_MIC', state = NetworkIsPlayerTalking(p), radio = inRadioTalking })
        end
        Wait(sleep)
    end
end)

CreateThread(function()
    while true do
        if IsControlJustPressed(0, Config.Keybind.belt) then ToggleSeatbelt() end
        if IsControlJustPressed(0, Config.Keybind.settings_menu) then SettingsMenu() end
        if IsControlJustPressed(0, Config.Keybind.editormode.modifier) then Customization() end
        if inCar and seatbeltOn then DisableControlAction(0, 75, true) end

        HideHudComponentThisFrame(2)
        HideHudComponentThisFrame(3)
        HideHudComponentThisFrame(4)
        HideHudComponentThisFrame(6)
        HideHudComponentThisFrame(7)
        HideHudComponentThisFrame(8)
        HideHudComponentThisFrame(9)

        if cinematicMode then
            DisplayRadar(false)
        else
            if not radarHideForTrigger then
                if Config.ShowMapOnlyInTheCar then DisplayRadar(inCar) else DisplayRadar(true) end
                if Config.PostalMap then SetRadarZoom(1100) end
            else
                DisplayRadar(false)
            end
        end
        Wait(1)
    end
end)

CreateThread(function()
    while true do
        if inCar and not seatbeltOn and not beltIgnore then
            -- Optional sound support if interact-sound is installed.
            if GetResourceState('interact-sound') == 'started' then
                TriggerEvent('InteractSound_CL:PlayOnOne', 'beltalarm', 0.20)
            end
        end
        Wait(7500)
    end
end)

CreateThread(function()
    while true do
        if playerLoaded then
            local x, y = GetActiveScreenResolution()
            if screen.x ~= x or screen.y ~= y then
                screen.x, screen.y = x, y
                buildmap()
            end
        end
        Wait(5000)
    end
end)
