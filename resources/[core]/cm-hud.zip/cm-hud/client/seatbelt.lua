newvehicleBodyHealth, currentvehicleBodyHealth, frameBodyChange = 0, 0, 0
lastFrameVehiclespeed, lastFrameVehiclespeed2, thisFrameVehicleSpeed, tick = 0, 0, 0, 0
local lastVehicle = nil
local veloc = vector3(0.0, 0.0, 0.0)

local function EjectFromVehicle()
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then return end
    local coords = GetOffsetFromEntityInWorldCoords(veh, 1.0, 0.0, 1.0)
    SetEntityCoords(ped, coords.x, coords.y, coords.z)
    Wait(1)
    SetPedToRagdoll(ped, 5511, 5511, 0, false, false, false)
    SetEntityVelocity(ped, veloc.x * 4, veloc.y * 4, veloc.z * 4)
    local ejectspeed = math.ceil(GetEntitySpeed(ped) * 8)
    if GetEntityHealth(ped) - ejectspeed > 0 then
        SetEntityHealth(ped, GetEntityHealth(ped) - ejectspeed)
    elseif GetEntityHealth(ped) ~= 0 then
        SetEntityHealth(ped, 0)
    end
end

function ToggleSeatbelt()
    local ped = PlayerPedId()
    if not IsPedInAnyVehicle(ped, false) or IsPauseMenuActive() then return end
    local class = GetVehicleClass(GetVehiclePedIsUsing(ped))
    if class == 8 or class == 13 or class == 14 then
        TriggerEvent('wais:addNotification', 'warning', 'Seatbelt', Config.Notifications.cant_belt, 2500)
        return
    end
    if beltIgnore then return end

    seatbeltOn = not seatbeltOn
    if GetResourceState('interact-sound') == 'started' then
        TriggerEvent('InteractSound_CL:PlayOnOne', seatbeltOn and 'carbuckle' or 'carunbuckle', 0.25)
    end
    TriggerEvent('wais:addNotification', 'info', 'Seatbelt', seatbeltOn and Config.Notifications.belt_plug or Config.Notifications.belt_unplug, 2500)
end

RegisterNetEvent('EnteredVehicle', function()
    local playerPed = PlayerPedId()
    while IsPedInAnyVehicle(playerPed, false) do
        Wait(0)
        local currentVehicle = GetVehiclePedIsIn(playerPed, false)
        if currentVehicle and currentVehicle ~= 0 then
            lastVehicle = currentVehicle
            thisFrameVehicleSpeed = GetEntitySpeed(currentVehicle) * 3.6
            currentvehicleBodyHealth = GetVehicleBodyHealth(currentVehicle)
            if currentvehicleBodyHealth == 1000 and frameBodyChange ~= 0 then frameBodyChange = 0 end
            if frameBodyChange ~= 0 and lastFrameVehiclespeed > 110 and thisFrameVehicleSpeed < (lastFrameVehiclespeed * 0.75) then
                if not seatbeltOn and not IsThisModelABike(currentVehicle) then
                    local chance = frameBodyChange > 18.0 and 60 or 75
                    if math.random(math.ceil(lastFrameVehiclespeed)) > chance then EjectFromVehicle() end
                end
            end
            if lastFrameVehiclespeed < 100 then Wait(100) tick = 0 end
            frameBodyChange = newvehicleBodyHealth - currentvehicleBodyHealth
            if tick > 0 then
                tick = tick - 1
                if tick == 1 then lastFrameVehiclespeed = GetEntitySpeed(currentVehicle) * 3.6 end
            else
                lastFrameVehiclespeed2 = GetEntitySpeed(currentVehicle) * 3.6
                if lastFrameVehiclespeed2 > lastFrameVehiclespeed then lastFrameVehiclespeed = lastFrameVehiclespeed2 end
                if lastFrameVehiclespeed2 < lastFrameVehiclespeed then tick = 25 end
            end
            if tick < 0 then tick = 0 end
            newvehicleBodyHealth = GetVehicleBodyHealth(currentVehicle)
            veloc = GetEntityVelocity(currentVehicle)
        else
            if lastVehicle then
                Wait(200)
                newvehicleBodyHealth = GetVehicleBodyHealth(lastVehicle)
                lastVehicle = nil
            end
            lastFrameVehiclespeed2, lastFrameVehiclespeed = 0, 0
            newvehicleBodyHealth, currentvehicleBodyHealth, frameBodyChange = 0, 0, 0
            Wait(2000)
            break
        end
    end
end)
