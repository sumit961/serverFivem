(() => {
  const RES = (typeof GetParentResourceName === 'function') ? GetParentResourceName() : 'cm-hud';
  const $ = (id) => document.getElementById(id);
  let speedType = localStorage.getItem('wais-speedType') || 'kmh';
  let cinematic = false;
  let editing = false;

  function post(name, data = {}) {
    try {
      fetch(`https://${RES}/${name}`, {
        method: 'POST',
        headers: {'Content-Type':'application/json; charset=UTF-8'},
        body: JSON.stringify(data)
      }).then(r => r.text()).catch(e => console.error('[cm-hud] fetch failed', name, e));
    } catch (e) { console.error('[cm-hud] post error', name, e); }
  }

  function fmtMoney(n) {
    n = Number(n || 0);
    return '$' + n.toLocaleString();
  }

  function setFill(id, val) {
    const el = $(id);
    if (el) el.style.height = Math.max(0, Math.min(100, Number(val || 0))) + '%';
  }

  function notify(data) {
    const wrap = $('notifications');
    const id = 'n' + Date.now() + Math.random().toString(16).slice(2);
    const div = document.createElement('div');
    div.className = 'note ' + (data.ntype || data.types || 'info');
    div.id = id;
    div.innerHTML = `<b>${data.title || 'Notification'}</b><span>${data.text || data.message || ''}</span>`;
    wrap.prepend(div);
    setTimeout(() => div.remove(), Number(data.time || data.timeout || 3500));
  }

  function showPanel(id, state) {
    $(id).classList.toggle('hidden', !state);
  }

  function toggleCinematic(state) {
    cinematic = typeof state === 'boolean' ? state : !cinematic;
    $('cinematicTop').classList.toggle('active', cinematic);
    $('cinematicBottom').classList.toggle('active', cinematic);
  }

  function updateVehicle(v) {
    $('vehicle').classList.remove('hidden');
    let raw = Number(v.speed || 0);
    let spd = speedType === 'mph' ? raw * 2.236936 : raw * 3.6;
    $('speed').textContent = String(Math.floor(spd)).padStart(3, '0');
    $('speedUnit').textContent = speedType.toUpperCase();
    $('rpmFill').style.width = Math.min(100, Math.max(0, Number(v.rpm || 0) * (Number(v.rpm) <= 1 ? 100 : 11))) + '%';
    $('gear').textContent = Number(v.gear || 0) === 0 ? 'N' : v.gear;
    $('maxGear').textContent = v.maxgear || v.maxGear || '6';
    $('fuel').innerHTML = `⛽ <b>${Math.floor(Number(v.fuel || 0))}%</b>`;
    $('fuel').classList.toggle('warn', Number(v.fuel || 0) < 20);
    setIcon('seatbelt', v.seatbelt ?? v.belt);
    setIcon('door', v.door, true);
    setIcon('light', v.light);
    setIcon('engine', v.engine);
    setIcon('brake', v.handbrake ?? v.hbreake, true);
    const dmg = Math.max(0, Math.min(100, Math.floor(Number(v.engineDamage ?? v.damage ?? 1000) / 10)));
    $('damage').textContent = `🔧 ${dmg}%`;
    $('damage').classList.toggle('bad', dmg < 35);
  }

  function setIcon(id, state, warnWhenOn=false) {
    const el = $(id);
    el.classList.toggle('on', !!state && !warnWhenOn);
    el.classList.toggle('warn', !!state && warnWhenOn);
  }

  window.addEventListener('message', (ev) => {
    const d = ev.data || {};
    switch (d.type) {
      case 'DEFAULT_VERIABLES':
        speedType = localStorage.getItem('wais-speedType') || speedType;
        break;
      case 'PLAYER_LOADED':
        $('playerId').textContent = 'ID ' + (d.playerId || 0);
        $('hud').classList.remove('hidden');
        break;
      case 'UPDATE_CURRENT_PLAYERS':
        $('players').textContent = `${d.players || 0}/${d.maxplayers || 32}`;
        break;
      case 'UPDATE_CASH':
        $('cash').textContent = fmtMoney(d.cash);
        break;
      case 'UPDATE_BANK':
        $('bank').textContent = fmtMoney(d.bank);
        break;
      case 'UPDATE_JOB':
        $('job').textContent = d.label || 'Unemployed';
        break;
      case 'UPDATE_STATUS': {
        const health = d.health ?? d.heal ?? 100;
        const armour = d.armour ?? 0;
        $('healthText').textContent = Math.floor(health) + '%';
        $('armourText').textContent = Math.floor(armour) + '%';
        setFill('healthFill', health);
        setFill('armourFill', armour);
        $('water').classList.toggle('active', !!(d.inwater ?? d.weather));
        break;
      }
      case 'UPDATE_MIC_DISTANCE':
        $('micText').textContent = (d.distance || 35) + 'm';
        setFill('micFill', Math.min(100, Number(d.distance || 35)));
        break;
      case 'UPDATE_MIC':
        $('micIcon').textContent = d.state ? '🔊' : '🎙';
        document.querySelector('.mic').classList.toggle('on', !!d.state || !!d.radio);
        break;
      case 'UPDATE_LOCATION':
        $('streetTitle').textContent = d.streetTitle || 'Unknown Street';
        $('streetName').textContent = d.streetName || '';
        $('waypoint').textContent = d.remaining ? `${d.remainingDistance || 0}m` : '';
        break;
      case 'PLAYER_INCAR':
        $('vehicle').classList.remove('hidden');
        break;
      case 'PLAYER_OUTCAR':
        $('vehicle').classList.add('hidden');
        break;
      case 'VEHICLE_STATUS':
      case 'UPDATE_VEHICLE_STATUS':
        updateVehicle(d);
        break;
      case 'UPDATE_WEAPON':
        if (d.label && d.label !== '-1569615261' && d.ammo !== 0) {
          $('weapon').classList.remove('hidden');
          $('weaponName').textContent = d.label || 'Weapon';
          $('ammo').textContent = `${d.ammo || 0} / ${d.clip || 0}`;
          const img = $('weaponImg');
          img.style.display = '';
          img.src = `public/weapons/${d.image}.png`;
        } else {
          $('weapon').classList.add('hidden');
        }
        break;
      case 'ADD_NOTIFICATION':
        notify(d);
        break;
      case 'SETTINGS_MENU':
        showPanel('settings', !!d.state);
        break;
      case 'CUSTOMIZATION_MENU':
        editing = !!d.state;
        document.body.classList.toggle('editing', editing);
        showPanel('editor', editing);
        break;
      case 'PAUSEMENU_STATE':
        $('hud').classList.toggle('hidden', !!d.state);
        break;
      case 'CM_CLEAR_STORAGE':
        localStorage.clear();
        notify({ntype:'success', title:'HUD', text:'Settings reset', time:2500});
        break;
      case 'RELOAD_PAGE':
        location.reload();
        break;
    }
  });

  document.addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-action]');
    if (!btn) return;
    const a = btn.dataset.action;
    if (a === 'close') { showPanel('settings', false); post('closeSettings'); }
    if (a === 'close-editor') { editing = false; document.body.classList.remove('editing'); showPanel('editor', false); post('closeEditorMode'); }
    if (a === 'map-square') { localStorage.setItem('wais-mapType','squared'); post('setmaptype', {map:'squared'}); notify({title:'HUD', text:'Square minimap selected'}); }
    if (a === 'map-circle') { localStorage.setItem('wais-mapType','rounded'); post('setmaptype', {map:'rounded'}); notify({title:'HUD', text:'Circle minimap selected'}); }
    if (a === 'speed-kmh') { speedType='kmh'; localStorage.setItem('wais-speedType','kmh'); post('setspeedtype', {speed:'kmh'}); }
    if (a === 'speed-mph') { speedType='mph'; localStorage.setItem('wais-speedType','mph'); post('setspeedtype', {speed:'mph'}); }
    if (a === 'cinematic') { toggleCinematic(); post('cinematicmode', {state:cinematic}); }
    if (a === 'reset') { localStorage.clear(); notify({title:'HUD', text:'Settings reset'}); }
  });

  // Simple draggable editor
  let drag = null;
  document.addEventListener('mousedown', (e) => {
    if (!editing) return;
    const el = e.target.closest('.server-card,.money-row,.job-card,.status,.location,.vehicle,.weapon');
    if (!el) return;
    drag = {el, x:e.clientX, y:e.clientY, left:el.offsetLeft, top:el.offsetTop};
    e.preventDefault();
  });
  document.addEventListener('mousemove', (e) => {
    if (!drag) return;
    drag.el.style.left = (drag.left + e.clientX - drag.x) + 'px';
    drag.el.style.top = (drag.top + e.clientY - drag.y) + 'px';
    drag.el.style.right = 'auto';
    drag.el.style.bottom = 'auto';
  });
  document.addEventListener('mouseup', () => { drag = null; });

  // Handshake with Lua. This is the part that was failing in the React build.
  function loaded() {
    post('nuiloaded', {
      statusbartype: localStorage.getItem('wais-hudType') || 'newest',
      carhudtype: localStorage.getItem('wais-carhudType') || 'new',
      maptype: localStorage.getItem('wais-mapType') || 'squared',
      speedtype: localStorage.getItem('wais-speedType') || 'kmh'
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    loaded();
    setTimeout(loaded, 1000);
    setTimeout(loaded, 3000);
    notify({ntype:'success', title:'cm-hud', text:'HUD loaded', time:2500});
  });
})();